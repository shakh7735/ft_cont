#!/bin/bash

FT_CONTAINERS="../../ft_containers"
